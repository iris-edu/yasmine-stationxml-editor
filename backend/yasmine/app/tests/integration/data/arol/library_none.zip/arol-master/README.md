# AROL

Atomic Response Objects Library containing metadata descriptions of earth science observation instruments

Contain the objets used within RESIF 

* schema folder  contain a schema of yaml files. There are two type of files : response and filter.
* ObjetsYaml contains yaml expression for objects response
* The IsValid script is used to check if YAML files are valide 

